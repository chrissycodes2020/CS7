// chrissy stevens //

var x ="This came from my variable x!";
document.write("This came from my script, and is now on the page! <br>");
document.write(x);