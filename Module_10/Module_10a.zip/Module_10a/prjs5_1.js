var payCheck = 2000;

var payCheck = payCheck * 2 - 500 - 3500 + 500 - 80;

console.log (payCheck);